package com.difrancescogianmarco.arcore_flutter_plugin.flutter_models

import com.google.ar.core.Plane

class FlutterArCorePlane(val type: Plane.Type) {}