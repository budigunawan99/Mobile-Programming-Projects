<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class TokoHape extends Model {

	public static function getAllData(){
		//$results = DB::table('smartphone')->get();		
		$results = DB::select('SELECT id as productId, name as productName, category, description, photo, price from smartphone ORDER BY id ASC');		
        return $results;
    }	
}
