<?php namespace App\Http\Controllers\TokoHape;

use App\Models\TokoHape;
use App\Http\Controllers\Controller;
use Response, View, XMLWriter, Storage;

class TokoHapeController extends Controller {

	public function write_json(){
		$result = TokoHape::getAllData();	
		$array = array("products"=>$result);
		echo json_encode($array);
	}
	
	public function write_xml(){
		$result = TokoHape::getAllData();

		$xml = new XMLWriter();
		$xml->openMemory();
		$xml->startDocument();
		$xml->startElement('tokoHape');
		foreach($result as $rows) {
			$xml->startElement('products');
			$xml->writeElement('productId', $rows->productId);
			$xml->writeElement('productName', $rows->productName);
			$xml->writeElement('category', $rows->category);
			$xml->writeElement('description', $rows->description);
			$xml->writeElement('photo', $rows->photo);
			$xml->writeElement('price', $rows->price);
			$xml->endElement();
		}
		$xml->endElement();
		$xml->endDocument();

		$content = $xml->outputMemory();
		$xml = null;

		return response($content)->header('Content-Type', 'text/xml');
		}
		
	public function show_photo($filename){
		
		if (!Storage::exists('foto/'.$filename)) {
            return Response::make('File not found.', 404);
        }
		
		$file = Storage::get('foto/'.$filename);
        $response = Response::make($file, 200)->header('Content-Type', 'image/jpeg');
		
        return $response;
		
	}
	
}
