<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('toko-hape/rest/list/json', 'TokoHape\TokoHapeController@write_json');
Route::get('toko-hape/rest/list/xml', 'TokoHape\TokoHapeController@write_xml');

Route::get('toko-hape/foto/{filename}', 'TokoHape\TokoHapeController@show_photo');
