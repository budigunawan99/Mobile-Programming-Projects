<?php

	var_dump($result);