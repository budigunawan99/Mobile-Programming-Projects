package id.ac.unsyiah.android.tugas3;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edtNo, edtNama, edtJurusan, edtNpm;

    DataMahasiswa dataMahasiswa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtNo = findViewById(R.id.edt_no);
        edtNpm = findViewById(R.id.edt_npm);
        edtNama = findViewById(R.id.edt_nama);
        edtJurusan = findViewById(R.id.edt_jurusan);

        dataMahasiswa = new DataMahasiswa(this);
    }

    private void insertData() {
        Mahasiswa sp = new Mahasiswa();
        sp.setNo(Integer.parseInt(edtNo.getText().toString()));
        sp.setNpm(Long.parseLong(edtNpm.getText().toString()));
        sp.setNama(edtNama.getText().toString());
        sp.setJurusan(edtJurusan.getText().toString());

        dataMahasiswa.buka();
        dataMahasiswa.addMahasiwa(sp);
        edtNo.setText("");
        edtNpm.setText("");
        edtNama.setText("");
        edtJurusan.setText("");
        dataMahasiswa.tutup();

        Toast.makeText(MainActivity.this, "Data berhasil disimpan", Toast.LENGTH_LONG).show();
    }

    public void simpan(View view) {
        int no = Integer.parseInt(edtNo.getText().toString());
        long npm = Long.parseLong(edtNpm.getText().toString());
        String nama = edtNama.getText().toString();
        String jurusan = edtJurusan.getText().toString();
        if (no == 0) {
            return;
        } else if (npm == 0){
            return;
        } else if (nama.isEmpty()) {
            return;
        } else if(jurusan.isEmpty()){
            return;
        }else {
            this.insertData();
        }
    }

    @SuppressLint("DefaultLocale")
    public void btnGetAll(View view) {
        dataMahasiswa.buka();
        Mahasiswa[] listIdentitas = dataMahasiswa.getAllIdentitas();
        dataMahasiswa.tutup();
        if (listIdentitas!=null) {
            StringBuilder hasil = new StringBuilder();
            for (Mahasiswa identitas: listIdentitas) {
                hasil.append(String.format("No : %d, NPM : %d, Nama : %s, Jurusan : %s\n",
                        identitas.getNo(),
                        identitas.getNpm(),
                        identitas.getNama(),
                        identitas.getJurusan()));
            }
            Toast.makeText(this, hasil.toString(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Tidak ada data", Toast.LENGTH_SHORT).show();
        }
    }

    public void btnGetByKode(View view) {
        String no = edtNo.getText().toString();
        dataMahasiswa.buka();
        Mahasiswa identitas = dataMahasiswa.getIdentitas(no);
        dataMahasiswa.tutup();
        if (identitas != null) {
            @SuppressLint("DefaultLocale") String hasil = String.format("No : %d, NPM : %d, Nama : %s, Jurusan : %s\n",
                    identitas.getNo(),
                    identitas.getNpm(),
                    identitas.getNama(),
                    identitas.getJurusan());
            edtNo.setText(String.valueOf(identitas.getNo()));
            edtNpm.setText(String.valueOf(identitas.getNpm()));
            edtNama.setText(identitas.getNama());
            edtJurusan.setText(identitas.getJurusan());
            Toast.makeText(this, hasil, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Tidak ada data", Toast.LENGTH_SHORT).show();
        }
    }

    public void btnDelete(View view) {
        String no = edtNo.getText().toString();
        dataMahasiswa.buka();
        if (dataMahasiswa.deleteIdentitas(no)) {
            Toast.makeText(this, "Berhasil dihapus", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Gagal dihapus", Toast.LENGTH_SHORT).show();
        }
    }

    public void btnUpdate(View view) {
        Mahasiswa data = new Mahasiswa();
        data.setNo(Integer.parseInt(edtNo.getText().toString()));
        data.setNama(edtNama.getText().toString());
        data.setJurusan(edtJurusan.getText().toString());
        dataMahasiswa.buka();
        if (dataMahasiswa.updateIdentitas(data)) {
            Toast.makeText(this, "Berhasil Update", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Gagal Update", Toast.LENGTH_SHORT).show();
        }
        dataMahasiswa.tutup();
    }

}
