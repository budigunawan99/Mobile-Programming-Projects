package com.travelblog.repository;

import com.travelblog.http.*;

import java.util.*;

public interface DataFromNetworkCallback {
    void onSuccess(List<Blog> blogList);

    void onError();
}
