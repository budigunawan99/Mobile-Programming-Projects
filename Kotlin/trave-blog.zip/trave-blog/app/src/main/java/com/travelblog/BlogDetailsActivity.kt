package com.travelblog

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Html
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.travelblog.http.Blog
import kotlinx.android.synthetic.main.activity_blog_details.*

class BlogDetailsActivity : AppCompatActivity() {

    companion object {
        private const val EXTRAS_BLOG = "EXTRAS_BLOG"

        fun start(activity: Activity, blog: Blog) {
            val intent = Intent(activity, BlogDetailsActivity::class.java)
            intent.putExtra(EXTRAS_BLOG, blog)
            activity.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_blog_details)

        imageBack.setOnClickListener { finish() }

        intent.extras?.getParcelable<Blog>(EXTRAS_BLOG)?.let { blog ->
            showData(blog)
        }
    }

    private fun showData(blog: Blog) {
        progressBar.visibility = View.GONE
        textTitle.text = blog.title
        textDate.text = blog.date
        textAuthor.text = blog.author.name
        textRating.text = blog.rating.toString()
        textViews.text = String.format("(%d views)", blog.views)
        textDescription.text = Html.fromHtml(blog.description)
        ratingBar.rating = blog.rating
        ratingBar.visibility = View.VISIBLE

        Glide.with(this)
                .load(blog.getImageUrl())
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(imageMain)

        Glide.with(this)
                .load(blog.author.getAvatarUrl())
                .transform(CircleCrop())
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(imageAvatar)
    }

}